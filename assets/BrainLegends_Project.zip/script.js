document.addEventListener("DOMContentLoaded", () => {

    // =========================================
    // 1. SISTEM MUSIK (AUDIO MANAGER)
    // =========================================
    // Kode ini cukup SATU KALI saja di sini.
    let currentAudio = null; 

    function playMusic(fileName) {
        // Matikan lagu sebelumnya jika ada
        if (currentAudio) {
            currentAudio.pause();
            currentAudio.currentTime = 0;
        }

        // Siapkan lagu baru dari folder assets
        currentAudio = new Audio('assets/audio/music/' + fileName);
        currentAudio.loop = true; // Lagu mengulang terus
        currentAudio.volume = 0.5; // Volume setengah

        // Mainkan lagu
        currentAudio.play().catch(error => {
            console.log("Musik tertahan browser, menunggu interaksi user.");
        });
    }


    // =========================================
    // 2. GENERATE MATRIX (BACKGROUND SYSTEM)
    // =========================================
    const container = document.getElementById('matrix-container');
    const maxElements = 26000; 
    const chars = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const colors = ['#FFFFFF', '#FF0000', '#00FF00', '#00FFFF', '#FFFF00', '#FF00FF', '#FFA500'];
    const fragment = document.createDocumentFragment();
    let count = 0;
    
    for (let c = 0; c < colors.length; c++) {
        const currentColor = colors[c];
        for (let i = 0; i < chars.length; i++) {
            for (let j = 0; j < chars.length; j++) {
                if (count >= maxElements) break; 
                const span = document.createElement('div');
                span.className = 'c'; span.textContent = chars[i] + chars[j]; span.style.color = currentColor;
                fragment.appendChild(span); count++;
            }
            if (count >= maxElements) break;
        }
        if (count >= maxElements) break;
    }
    container.appendChild(fragment);


    // =========================================
    // 3. LOGIKA GAMEPLAY UTAMA (TOMBOL & MODE)
    // =========================================
    const btnPlay = document.getElementById('btn-play');
    const btnClassic = document.getElementById('btn-classic');
    const btnRanked = document.getElementById('btn-ranked');
    let currentMode = ""; 

    // --- LOGIKA TOMBOL CLASSIC (UPDATE AUDIO & BG) ---
    btnClassic.addEventListener('click', () => {
        currentMode = "Classic";
        
        // 1. Tampilan Tombol
        btnClassic.classList.add('mode-selected'); 
        btnClassic.style.backgroundColor = "#3498db"; 
        
        btnRanked.classList.remove('mode-selected'); 
        btnRanked.style.backgroundColor = "#f1c40f"; 
        
        // 2. Aktifkan Play
        btnPlay.removeAttribute('disabled'); 
        btnPlay.innerText = "PLAY (Classic)";

        // 3. Ganti Background
        document.body.style.backgroundImage = "url('assets/images/backgrounds/bg-classic.jpg')";

        // 4. GANTI MUSIK KE CLASSIC
        playMusic('bgm-classic.mp3');
    });

    // --- LOGIKA TOMBOL RANKED (UPDATE AUDIO & BG) ---
    btnRanked.addEventListener('click', () => {
        currentMode = "Ranked";
        
        // 1. Tampilan Tombol
        btnRanked.classList.add('mode-selected'); 
        btnRanked.style.backgroundColor = "#e67e22"; 
        
        btnClassic.classList.remove('mode-selected'); 
        btnClassic.style.backgroundColor = "#ecf0f1"; 
        
        // 2. Aktifkan Play
        btnPlay.removeAttribute('disabled'); 
        btnPlay.innerText = "PLAY (Ranked)";

        // 3. Ganti Background
        document.body.style.backgroundImage = "url('assets/images/backgrounds/bg-ranked.jpg')";

        // 4. GANTI MUSIK KE RANKED
        playMusic('bgm-ranked.mp3');
    });

    // --- TOMBOL PLAY ---
    btnPlay.addEventListener('click', () => {
        if (currentMode === "") return;
        alert("Game Start: " + currentMode);
    });


        // =========================================
    // 4. LOGIKA CHAT FULL SCREEN (BARU)
    // =========================================
    
    // Ambil Elemen dari HTML
    const btnOpenChat = document.getElementById('btn-open-chat');
    const btnCloseChat = document.getElementById('btn-close-chat');
    const chatScreen = document.getElementById('chat-fullscreen');
    
    // Elemen Tab (Tombol Pindah)
    const tabGlobal = document.getElementById('tab-global');
    const tabFriend = document.getElementById('tab-friend');
    const tabSquad = document.getElementById('tab-squad');

    // Elemen Konten (Isi Pesan)
    const contentGlobal = document.getElementById('content-global');
    const contentFriend = document.getElementById('content-friend');
    const contentSquad = document.getElementById('content-squad');

    // --- FUNGSI 1: BUKA & TUTUP CHAT ---
    if (btnOpenChat && chatScreen) {
        // Buka Chat (Hapus class 'hidden')
        btnOpenChat.addEventListener('click', () => {
            chatScreen.classList.remove('hidden');
        });
        
        // Tutup Chat (Tambah class 'hidden')
        btnCloseChat.addEventListener('click', () => {
            chatScreen.classList.add('hidden');
        });
    }

    // --- FUNGSI 2: PINDAH TAB (GLOBAL / TEMAN / SQUAD) ---
    function switchTab(mode) {
        // 1. Reset Semua Tombol (Biar gak kuning semua)
        tabGlobal.classList.remove('active');
        tabFriend.classList.remove('active');
        tabSquad.classList.remove('active');

        // 2. Sembunyikan Semua Isi Pesan
        contentGlobal.classList.add('hidden');
        contentFriend.classList.add('hidden');
        contentSquad.classList.add('hidden');

        // 3. Aktifkan Salah Satu Sesuai Pilihan
        if (mode === 'global') {
            tabGlobal.classList.add('active');     // Tombol jadi kuning
            contentGlobal.classList.remove('hidden'); // Isi chat muncul
        } else if (mode === 'friend') {
            tabFriend.classList.add('active');
            contentFriend.classList.remove('hidden');
        } else if (mode === 'squad') {
            tabSquad.classList.add('active');
            contentSquad.classList.remove('hidden');
        }
    }



    // --- FUNGSI 3: LOGIKA PRIVATE CHAT (DAFTAR KE ROOM) ---
    const friendListView = document.getElementById('friend-list-view');
    const privateChatView = document.getElementById('private-chat-view');
    const btnBackFriend = document.getElementById('btn-back-friend');
    const targetFriendName = document.getElementById('target-friend-name');

    // Daftar Teman Dummy (Contoh)
    const friend1 = document.getElementById('friend-1'); // Lancelot
    const friend2 = document.getElementById('friend-2'); // Miya

    // Logika: Masuk ke Chat Lancelot
    if(friend1) {
        friend1.addEventListener('click', () => {
            friendListView.classList.add('hidden');     // Sembunyikan Daftar
            privateChatView.classList.remove('hidden'); // Munculkan Room Chat
            targetFriendName.innerText = "Lancelot";    // Ganti Judul
        });
    }

    // Logika: Masuk ke Chat Miya
    if(friend2) {
        friend2.addEventListener('click', () => {
            friendListView.classList.add('hidden');
            privateChatView.classList.remove('hidden');
            targetFriendName.innerText = "Miya";
        });
    }

    // Logika: Tombol KEMBALI
    if(btnBackFriend) {
        btnBackFriend.addEventListener('click', () => {
            privateChatView.classList.add('hidden');    // Sembunyikan Room Chat
            friendListView.classList.remove('hidden');  // Munculkan Daftar Lagi
        });
    }




    // Pasang Event Listener ke Tombol Tab
    if (tabGlobal) tabGlobal.addEventListener('click', () => switchTab('global'));
    if (tabFriend) tabFriend.addEventListener('click', () => switchTab('friend'));
    if (tabSquad)  tabSquad.addEventListener('click', () => switchTab('squad'));




    // 5. LOGIKA MENU BAWAH (CARD, EQUIP, SHOP)
    // =========================================
    const btnCard = document.getElementById('btn-card');
    const btnEquip = document.getElementById('btn-equip');
    const btnShop = document.getElementById('btn-shop');

    if(btnCard) {
        btnCard.addEventListener('click', () => {
            console.log("Buka Menu Card");
        });
    }

    if(btnEquip) {
        btnEquip.addEventListener('click', () => {
            console.log("Buka Menu Equipment");
        });
    }

    if(btnShop) {
        btnShop.addEventListener('click', () => {
            console.log("Buka Shop");
        });
    }


    // =========================================
    // 6. PEMICU MUSIK LOBBY (PERTAMA KALI)
    // =========================================
    // Musik Lobby akan bunyi saat user klik layar pertama kali
    document.body.addEventListener('click', function() {
        if (!currentAudio) {
            playMusic('bgm-lobby.mp3');
        }
    }, { once: true });




    // =========================================
    // 7. LOGIKA UI BARU (PROFIL, PASS, SETTING, DLL)
    // =========================================
    
    // Fungsi Pembuka Overlay Pintar
    function setupOverlay(btnId, overlayId) {
        const btn = document.getElementById(btnId);
        const overlay = document.getElementById(overlayId);
        
        if (btn && overlay) {
            // Tombol Buka
            btn.addEventListener('click', () => {
                overlay.classList.remove('hidden');
            });
            
            // Tombol Tutup (Cari tombol X di dalam overlay ini)
            const closeBtn = overlay.querySelector('.close-overlay');
            if (closeBtn) {
                closeBtn.addEventListener('click', () => {
                    overlay.classList.add('hidden');
                });
            }
        }
    }

    // Pasangkan Tombol ke Layarnya Masing-Masing
    setupOverlay('profile-card', 'overlay-profile'); // Klik Profil
    setupOverlay('btn-brain-pass', 'overlay-pass');  // Klik Brain Pass
    setupOverlay('btn-setting', 'overlay-setting');  // Klik Setting
    setupOverlay('btn-pib', 'overlay-pib');          // Klik P.I.B
    setupOverlay('btn-notif', 'overlay-notif');      // Klik Notif

    // Shop (Semua tombol uang lari ke Shop)
    const shopOverlay = document.getElementById('overlay-shop');
    const closeShop = shopOverlay.querySelector('.close-overlay');
    
    // Fungsi Buka Shop
    function openShop() { 
        if(shopOverlay) shopOverlay.classList.remove('hidden'); 
    }
    
    // Pasang ke tombol Koin, Blue Dia, Red Dia
    const btnCoin = document.getElementById('btn-coin');
    const btnBlueDia = document.getElementById('btn-blue-dia');
    const btnRedDia = document.getElementById('btn-red-dia');

    if(btnCoin) btnCoin.addEventListener('click', openShop);
    if(btnBlueDia) btnBlueDia.addEventListener('click', openShop);
    if(btnRedDia) btnRedDia.addEventListener('click', openShop);
    
    // Tombol Shop Bawah juga lari ke sini
    if(btnShop) btnShop.addEventListener('click', openShop);

    // Tutup Shop
    if(closeShop) {
        closeShop.addEventListener('click', () => {
            shopOverlay.classList.add('hidden');
        });
    }




});
